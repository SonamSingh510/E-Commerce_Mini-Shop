const express = require("express");
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const cors = require("cors");
require("dotenv").config();

const app = express();
app.use(express.json());

// FIX 1: Proper CORS configuration for local testing
app.use(
  cors({
    origin: "*",
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  }),
);

// --- 1. Database Connection (Updated for Cloud URI) ---
// Note: .env file mein MONGO_URI=your_atlas_connection_string zaroor likhna
const dbURI =
  process.env.MONGO_URI || "your_uri";

mongoose
  .connect(dbURI)
  .then(() => console.log("✅ MongoDB Atlas Connected Successfully"))
  .catch((err) => {
    console.log(
      "❌ DB Connection Error. Check your URI or Network Access in Atlas!",
    );
    console.error(err.message);
  });

// --- 2. Schemas & Models ---
const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, unique: true, required: true },
  password: { type: String, required: true },
  isAdmin: { type: Boolean, default: false },
});

const ProductSchema = new mongoose.Schema({
  name: String,
  price: Number,
  description: String,
  category: String,
  stock: Number,
});

const User = mongoose.model("User", UserSchema);
const Product = mongoose.model("Product", ProductSchema);

// --- 3. Middleware for Auth ---
const protect = (req, res, next) => {
  let token = req.headers.authorization;
  if (token && token.startsWith("Bearer")) {
    try {
      const decoded = jwt.verify(
        token.split(" ")[1],
        process.env.JWT_SECRET || "secret123",
      );
      req.user = decoded;
      next();
    } catch (error) {
      res.status(401).json({ message: "Not authorized, token failed" });
    }
  } else {
    res.status(401).json({ message: "No token, authorization denied" });
  }
};

// --- 4. API Routes ---

// Quick Data Seeding
app.get("/api/seed", async (req, res) => {
  try {
    await Product.deleteMany({});
    const products = await Product.insertMany([
      {
        name: "iPhone 15",
        price: 999,
        description: "Latest Apple Phone",
        category: "Electronics",
        stock: 10,
      },
      {
        name: "MacBook Pro",
        price: 1999,
        description: "Powerful M3 Chip",
        category: "Laptop",
        stock: 5,
      },
      {
        name: "AirPods Pro",
        price: 249,
        description: "Active Noise Cancellation",
        category: "Audio",
        stock: 20,
      },
    ]);
    res.json({ message: "Sample data added to Cloud!", products });
  } catch (err) {
    res.status(500).json({ message: "Seeding failed", error: err });
  }
});

// Auth Routes
app.post("/api/auth/register", async (req, res) => {
  const { name, email, password } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, password: hashedPassword });
    res.status(201).json({ message: "User Registered", userId: user._id });
  } catch (err) {
    res.status(400).json({ message: "Registration failed", error: err });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (user && (await bcrypt.compare(password, user.password))) {
      const token = jwt.sign(
        { id: user._id, isAdmin: user.isAdmin },
        process.env.JWT_SECRET || "secret123",
        { expiresIn: "30d" },
      );
      res.json({ token, name: user.name, isAdmin: user.isAdmin });
    } else {
      res.status(401).json({ message: "Invalid email or password" });
    }
  } catch (err) {
    res.status(500).json({ message: "Login error", error: err });
  }
});

// Product Routes
app.get("/api/products", async (req, res) => {
  try {
    const products = await Product.find({});
    res.json(products);
  } catch (err) {
    res.status(500).json({ message: "Error fetching products" });
  }
});

app.post("/api/products", protect, async (req, res) => {
  if (!req.user.isAdmin)
    return res.status(403).json({ message: "Admin access required" });
  try {
    const product = await Product.create(req.body);
    res.status(201).json(product);
  } catch (err) {
    res.status(400).json({ message: "Product creation failed" });
  }
});

// --- 5. Server Start ---
const PORT = process.env.PORT || 5000;
app.listen(PORT, () =>
  console.log(`🚀 Server running at http://localhost:${PORT}`),
);